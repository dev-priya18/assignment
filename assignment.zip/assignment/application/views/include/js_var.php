<script>
var AUTH_KEY = '<?php  echo AUTH_KEY; ?>';
var site_url = '<?php echo site_url();?>';

	
</script>