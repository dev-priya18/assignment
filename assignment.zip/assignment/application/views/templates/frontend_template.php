<?php $this->load->view('templates/frontend_header');  ?>
 
 <ui-view></ui-view>

 <?php $this->load->view('templates/frontend_footer');  ?>


