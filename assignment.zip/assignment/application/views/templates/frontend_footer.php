  <div id="ng_load_plugins_before"></div>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="<?php echo FRONTEND_THEME_URL ?>js/vendor/bootstrap.min.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/vendor/angular-sanitize.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/vendor/angular-ui-router.min.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/vendor/ocLazyLoad.min.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/app.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/service/service.js"></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/lodash.js" type="text/javascript" ></script>
  <script src="<?php echo FRONTEND_THEME_URL ?>js/vendor/angular-ui-tree.js"></script>
  </body>
</html>
